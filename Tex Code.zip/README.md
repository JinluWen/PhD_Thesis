Readme

main_EN.tex is the main tex file, and EN_Ref_Compile20250307.pdf is a reference pdf file. Compile with TexLive 2024.

Please cite the publisher’s Chinese version to avoid copyright issues.

中文版本请编译main.tex，博士论文 温金录 最终版 二五年三月一日编译.pdf  为参考版本。使用 TexLive 2024编译。

引用请引用出版社处中文版本，避免版权纠纷。